/**
 * Extracts a YouTube video ID from various URL formats or validates a raw video ID.
 * Supports:
 * - youtu.be/<id>
 * - youtube.com/watch?v=<id>
 * - youtube.com/shorts/<id>
 * - youtube.com/embed/<id>
 * - Raw video ID (11 characters)
 * 
 * @param input - YouTube URL or video ID
 * @returns The extracted video ID or null if invalid
 */
export function extractVideoId(input: string): string | null {
  const trimmed = input.trim();
  
  if (!trimmed) {
    return null;
  }

  // YouTube video IDs are typically 11 characters long
  const videoIdRegex = /^[a-zA-Z0-9_-]{11}$/;

  // Check if input is already a valid video ID
  if (videoIdRegex.test(trimmed)) {
    return trimmed;
  }

  try {
    const url = new URL(trimmed);
    
    // youtu.be/<id>
    if (url.hostname === 'youtu.be') {
      const id = url.pathname.slice(1).split('?')[0];
      if (videoIdRegex.test(id)) {
        return id;
      }
    }
    
    // youtube.com/watch?v=<id>
    if (url.hostname.includes('youtube.com')) {
      // Check for /watch?v=<id>
      const vParam = url.searchParams.get('v');
      if (vParam && videoIdRegex.test(vParam)) {
        return vParam;
      }
      
      // Check for /shorts/<id>
      const shortsMatch = url.pathname.match(/^\/shorts\/([a-zA-Z0-9_-]{11})/);
      if (shortsMatch && shortsMatch[1]) {
        return shortsMatch[1];
      }
      
      // Check for /embed/<id>
      const embedMatch = url.pathname.match(/^\/embed\/([a-zA-Z0-9_-]{11})/);
      if (embedMatch && embedMatch[1]) {
        return embedMatch[1];
      }
    }
  } catch (e) {
    // Not a valid URL, continue to check other formats
  }

  // Try to extract ID from various URL patterns without URL parsing
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/
  ];

  for (const pattern of patterns) {
    const match = trimmed.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }

  return null;
}
