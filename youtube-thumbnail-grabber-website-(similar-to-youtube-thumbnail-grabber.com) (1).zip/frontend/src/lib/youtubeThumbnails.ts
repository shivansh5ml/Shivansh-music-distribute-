export interface ThumbnailVariant {
  label: string;
  resolution?: string;
  url: string;
}

/**
 * Generates all standard YouTube thumbnail variant URLs for a given video ID.
 * YouTube stores thumbnails at i.ytimg.com with various quality levels.
 * 
 * @param videoId - The YouTube video ID
 * @returns Array of thumbnail variants with labels, resolutions, and URLs
 */
export function getThumbnailVariants(videoId: string): ThumbnailVariant[] {
  const baseUrl = `https://i.ytimg.com/vi/${videoId}`;

  return [
    {
      label: 'Maximum Resolution',
      resolution: '1920×1080',
      url: `${baseUrl}/maxresdefault.jpg`
    },
    {
      label: 'Standard Definition',
      resolution: '640×480',
      url: `${baseUrl}/sddefault.jpg`
    },
    {
      label: 'High Quality',
      resolution: '480×360',
      url: `${baseUrl}/hqdefault.jpg`
    },
    {
      label: 'Medium Quality',
      resolution: '320×180',
      url: `${baseUrl}/mqdefault.jpg`
    },
    {
      label: 'Default',
      resolution: '120×90',
      url: `${baseUrl}/default.jpg`
    },
    {
      label: 'Thumbnail 1',
      resolution: '120×90',
      url: `${baseUrl}/1.jpg`
    },
    {
      label: 'Thumbnail 2',
      resolution: '120×90',
      url: `${baseUrl}/2.jpg`
    },
    {
      label: 'Thumbnail 3',
      resolution: '120×90',
      url: `${baseUrl}/3.jpg`
    }
  ];
}
