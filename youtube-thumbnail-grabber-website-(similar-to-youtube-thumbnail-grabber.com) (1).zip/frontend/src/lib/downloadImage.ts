/**
 * Downloads an image from a URL to the user's device.
 * Uses a fetch + blob approach to handle CORS and provide a clean download experience.
 * 
 * @param url - The image URL to download
 * @param filename - The desired filename for the downloaded image
 */
export async function downloadImage(url: string, filename: string): Promise<void> {
  try {
    // Fetch the image
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Failed to fetch image');
    }

    // Convert to blob
    const blob = await response.blob();

    // Create a temporary download link
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    
    // Trigger download
    document.body.appendChild(link);
    link.click();
    
    // Cleanup
    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);
  } catch (error) {
    console.error('Download failed:', error);
    // Fallback: open in new tab
    window.open(url, '_blank');
  }
}
