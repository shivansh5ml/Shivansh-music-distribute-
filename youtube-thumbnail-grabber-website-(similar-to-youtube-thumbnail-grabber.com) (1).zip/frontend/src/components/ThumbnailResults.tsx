import ThumbnailVariantCard from './ThumbnailVariantCard';
import { getThumbnailVariants } from '@/lib/youtubeThumbnails';

interface ThumbnailResultsProps {
  videoId: string;
}

export default function ThumbnailResults({ videoId }: ThumbnailResultsProps) {
  const variants = getThumbnailVariants(videoId);

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-4">Available Thumbnails</h2>
      <p className="text-muted-foreground mb-6">
        Click on any thumbnail to view it in full size, or use the action buttons to download or copy the link.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {variants.map((variant) => (
          <ThumbnailVariantCard
            key={variant.label}
            variant={variant}
            videoId={videoId}
          />
        ))}
      </div>
    </section>
  );
}
