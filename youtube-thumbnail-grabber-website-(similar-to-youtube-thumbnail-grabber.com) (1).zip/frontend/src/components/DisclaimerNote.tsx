import { Info } from 'lucide-react';

export default function DisclaimerNote() {
  return (
    <div className="bg-muted/50 rounded-lg p-4 border border-border">
      <div className="flex gap-3">
        <Info className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
        <div className="text-sm text-muted-foreground space-y-1">
          <p className="font-medium text-foreground">How it works</p>
          <p>
            This tool fetches thumbnails directly from YouTube's public image servers (i.ytimg.com). 
            No login or API key is required. Some thumbnail resolutions may not be available for all videos.
          </p>
        </div>
      </div>
    </div>
  );
}
