import { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, Copy, Download } from 'lucide-react';
import { downloadImage } from '@/lib/downloadImage';
import type { ThumbnailVariant } from '@/lib/youtubeThumbnails';

interface ThumbnailVariantCardProps {
  variant: ThumbnailVariant;
  videoId: string;
}

export default function ThumbnailVariantCard({ variant, videoId }: ThumbnailVariantCardProps) {
  const [isAvailable, setIsAvailable] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleImageLoad = () => {
    setIsLoading(false);
    setIsAvailable(true);
  };

  const handleImageError = () => {
    setIsLoading(false);
    setIsAvailable(false);
  };

  const handleOpen = () => {
    if (isAvailable) {
      window.open(variant.url, '_blank', 'noopener,noreferrer');
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(variant.url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  const handleDownload = async () => {
    if (isAvailable) {
      const filename = `${videoId}-${variant.label}.jpg`;
      await downloadImage(variant.url, filename);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center justify-between">
          <span>{variant.label}</span>
          {!isAvailable && (
            <span className="text-xs font-normal text-destructive bg-destructive/10 px-2 py-1 rounded">
              Unavailable
            </span>
          )}
        </CardTitle>
        {variant.resolution && (
          <p className="text-sm text-muted-foreground">{variant.resolution}</p>
        )}
      </CardHeader>
      <CardContent className="pb-3">
        <div className="relative bg-muted rounded-md overflow-hidden aspect-video">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="animate-pulse text-muted-foreground">Loading...</div>
            </div>
          )}
          <img
            src={variant.url}
            alt={`${variant.label} thumbnail`}
            className={`w-full h-full object-cover cursor-pointer transition-opacity ${
              isLoading ? 'opacity-0' : 'opacity-100'
            } ${isAvailable ? 'hover:opacity-90' : 'opacity-50'}`}
            onLoad={handleImageLoad}
            onError={handleImageError}
            onClick={handleOpen}
          />
          {!isAvailable && !isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80">
              <p className="text-sm font-medium text-muted-foreground">Not Available</p>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 pt-3">
        <Button
          variant="outline"
          size="sm"
          onClick={handleOpen}
          disabled={!isAvailable}
          className="flex-1 gap-2"
        >
          <ExternalLink className="h-4 w-4" />
          Open
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopyLink}
          className="flex-1 gap-2"
        >
          <Copy className="h-4 w-4" />
          {copiedLink ? 'Copied!' : 'Copy'}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleDownload}
          disabled={!isAvailable}
          className="flex-1 gap-2"
        >
          <Download className="h-4 w-4" />
          Download
        </Button>
      </CardFooter>
    </Card>
  );
}
