import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { extractVideoId } from '@/lib/youtubeParsing';
import ThumbnailResults from '@/components/ThumbnailResults';
import DisclaimerNote from '@/components/DisclaimerNote';
import { Copy, Trash2 } from 'lucide-react';

function App() {
  const [inputValue, setInputValue] = useState('');
  const [videoId, setVideoId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const handleGetThumbnails = () => {
    setError(null);
    setVideoId(null);
    setCopiedId(false);

    const trimmedInput = inputValue.trim();
    if (!trimmedInput) {
      setError('Please enter a YouTube URL or video ID');
      return;
    }

    const extractedId = extractVideoId(trimmedInput);
    if (!extractedId) {
      setError('Invalid YouTube URL or video ID. Please check your input and try again.');
      return;
    }

    setVideoId(extractedId);
  };

  const handleClear = () => {
    setInputValue('');
    setVideoId(null);
    setError(null);
    setCopiedId(false);
  };

  const handleCopyVideoId = async () => {
    if (videoId) {
      try {
        await navigator.clipboard.writeText(videoId);
        setCopiedId(true);
        setTimeout(() => setCopiedId(false), 2000);
      } catch (err) {
        console.error('Failed to copy video ID:', err);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleGetThumbnails();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-foreground">YouTube Thumbnail Grabber</h1>
          <p className="text-muted-foreground mt-2">Download YouTube video thumbnails in all available resolutions</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <section className="mb-8">
          <div className="bg-card rounded-lg overflow-hidden shadow-sm border border-border">
            <img 
              src="/assets/generated/yt-thumb-hero.dim_1200x400.png" 
              alt="YouTube Thumbnail Grabber Hero"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/1' }}
            />
          </div>
        </section>

        <section className="bg-card rounded-lg p-6 shadow-sm border border-border mb-8">
          <div className="space-y-4">
            <div>
              <Label htmlFor="youtube-input" className="text-base font-medium">
                YouTube URL or Video ID
              </Label>
              <p className="text-sm text-muted-foreground mt-1 mb-3">
                Paste a YouTube video URL or enter the video ID directly
              </p>
              <div className="flex gap-3">
                <Input
                  id="youtube-input"
                  type="text"
                  placeholder="e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ or dQw4w9WgXcQ"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                />
                <Button 
                  onClick={handleGetThumbnails}
                  size="lg"
                  className="px-8"
                >
                  Get Thumbnails
                </Button>
              </div>
              {error && (
                <p className="text-sm text-destructive mt-2 font-medium">{error}</p>
              )}
            </div>

            {videoId && (
              <div className="flex items-center gap-3 pt-2">
                <div className="flex-1 bg-muted rounded-md px-4 py-2">
                  <span className="text-sm text-muted-foreground">Video ID: </span>
                  <span className="text-sm font-mono font-medium">{videoId}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopyVideoId}
                  className="gap-2"
                >
                  <Copy className="h-4 w-4" />
                  {copiedId ? 'Copied!' : 'Copy ID'}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleClear}
                  className="gap-2"
                >
                  <Trash2 className="h-4 w-4" />
                  Clear
                </Button>
              </div>
            )}
          </div>
        </section>

        {videoId && <ThumbnailResults videoId={videoId} />}

        <DisclaimerNote />
      </main>

      <footer className="border-t border-border mt-16 py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>
            © 2026. Built with ❤️ using{' '}
            <a 
              href="https://caffeine.ai" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-foreground hover:text-primary transition-colors underline"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
