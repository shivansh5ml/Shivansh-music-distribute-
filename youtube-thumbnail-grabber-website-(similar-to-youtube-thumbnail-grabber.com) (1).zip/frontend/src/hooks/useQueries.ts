// This file is intentionally minimal as the app is fully client-side
// and does not require backend queries for the YouTube thumbnail functionality.
// All thumbnail operations are handled client-side using public YouTube image URLs.

export {};
