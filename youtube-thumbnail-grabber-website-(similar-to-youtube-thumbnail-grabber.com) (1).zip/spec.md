# Specification

## Summary
**Goal:** Build a single-page YouTube Thumbnail Grabber that lets users paste a YouTube URL or video ID and quickly view, copy, open, and download available thumbnail variants.

**Planned changes:**
- Create a single-page UI with an input for YouTube URL/ID, a “Get Thumbnails” button, and a results section that updates without page reload.
- Add client-side parsing/validation to extract video IDs from common YouTube URL formats and show clear English inline errors for invalid input (ignoring surrounding whitespace).
- Generate and display standard thumbnail variant cards using i.ytimg.com URLs, each with preview, label/resolution, and actions: Open (new tab), Copy Link (clipboard), Download (save with a sensible filename).
- Detect failed thumbnail loads per variant and mark them “Unavailable” while keeping other variants usable; disable Open/Download for unavailable variants.
- Add “Copy Video ID” and “Clear” controls plus a short English disclaimer noting thumbnails are fetched from YouTube’s public image endpoints.
- Apply a coherent, distinct visual theme (not blue/purple) with consistent typography, spacing, and clear hover/focus/disabled states across mobile and desktop.
- Add and render a generated static hero illustration from `frontend/public/assets/generated` in the page header/hero area without layout shift.

**User-visible outcome:** Users can paste a YouTube link or ID, fetch available thumbnail variants instantly on the page, and open/copy/download each image, with clear errors for invalid input and graceful handling of missing variants.
